
public class ProcessResult {
	public Process process;
	public String result;
	
	public ProcessResult(Process p, String r) {
		process = p;
		result = r;
	}
}
