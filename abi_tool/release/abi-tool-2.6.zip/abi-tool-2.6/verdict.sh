if [ -n "$1" ]; then
	java -jar verdict_checker.jar $1
fi
