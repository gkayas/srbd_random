java -jar git_repo_parser.jar
