java -jar compatibility_report_parser.jar compat_reports > ./logs/summary_report_generator.log
