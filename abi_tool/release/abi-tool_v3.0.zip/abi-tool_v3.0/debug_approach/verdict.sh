if [ -n "$1" ]; then
	echo "[FROM VERDICT SH]$1"
	java -jar verdict_checker.jar $1 $2 $3
fi
