#!/bin/bash
#
# Copyright (c) 2014 Samsung Electronics Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http:#www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

ABI_DIR="$(cd "$(dirname $0)" && pwd)"
OLD_XML="$ABI_DIR/OLD.xml"
NEW_XML="$ABI_DIR/NEW.xml"
OLD_REPO=$(cat abi.conf | awk '/^OLD_REPO:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
NEW_REPO=$(cat abi.conf | awk '/^NEW_REPO:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
GCC_PATH=$(cat abi.conf | awk '/^GCC_PATH:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
SYS_ROOT=$(cat abi.conf | awk '/^SYS_ROOT:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
HEADER_CHECKLIST=$(cat abi.conf | awk '/^HEADER_CHECKLIST:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
OLD_PKG_LIST=$(cat abi.conf | awk '/^OLD_PKG_LIST:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
NEW_PKG_LIST=$(cat abi.conf | awk '/^NEW_PKG_LIST:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
OLD_VER=$(cat abi.conf | awk '/^OLD_VER:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
NEW_VER=$(cat abi.conf | awk '/^NEW_VER:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
BASE_BINARY=$(cat abi.conf | awk '/^BASE_BINARY:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
COMPARED_BINARY=$(cat abi.conf | awk '/^COMPARED_BINARY:/ { print $2; exit; }')
if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure: failed to load abi.conf]."; exit 1; fi
LIB_DIR="\/usr\/lib"
ETC_DIR="\/usr\/etc"
USR_DIR="\/usr"

function remove()
{
	if [ "$1" == "-reports" ]; then
		find . -type d -name compat_reports -exec rm -rf {} \+
		echo "[!].......Current directory structure_______"
		find
	elif [ "$1" == "-temp" ]; then
		rm -rf old-pkg-mod.list
		rm -rf new-pkg-mod.list
		#~ rm -rf pkg2git-map.list
		rm -rf logs/downloaded_pkgs.log
	elif [ "$1" == "-pkg-list" ]; then
		rm -rf old-pkg.list
		rm -rf new-pkg.list
	elif [ "$1" == "-rpm" ]; then
		find . -type d -wholename "$NEW_RPM_DIR" -exec rm -rf {} \+
		find . -type d -wholename "$OLD_RPM_DIR" -exec rm -rf {} \+
	elif [ "$1" == "-pkg-comp" ]; then
		find $NEW_RPM_DIR/* -type d -exec rm -rf {} \+
		find $OLD_RPM_DIR/* -type d -exec rm -rf {} \+
	else
		echo "[!].......Nothing Removed."
	fi
}

function forcekill
{
	echo "[!].......CTRL-C was pressed"
	echo "[!].......Exiting script.."
	remove -reports
	remove -temp
	remove -pkg-list
	remove -rpm
	exit 1
}
trap forcekill 2

function installPkg()
{
	pkg=$1;
	if sudo dpkg --get-selections | grep -q "^$pkg[[:space:]]*install$" >/dev/null; then
		if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
	else
		echo "[!].......NOT INSTALLED! $pkg. Starting installation."
		echo "[#].......Starting installation."
		if sudo apt-get -qq install $pkg; then
			if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
			echo "[#].......Successfully installed $pkg."
		else
			echo "[!].......Error installing $pkg."
		fi	
	fi
	return 1
}
function helpusage {
# usage note
    echo "Usage: `basename $0` <-all|-limit|-p> <path/to/download/directory/for/old/repo/packages> <path/to/download/directory/for/new/repo/packages>"
    echo "Commands description:"
    echo "       -all      	test all packages of repos"
    echo "       -p      	test selected packages of repos (pattern accepted)"
    echo "       -limit		test packages of repos to a limited quota size (in megabytes)"
    echo "To test all the packages of repo, usage: `basename $0` -all <path/to/download/directory/for/old/repo/packages> <path/to/download/directory/for/new/repo/packages>"
    echo "To test limited packages of repo, usage: `basename $0` -limit <size_limit_in_megabytes> <path/to/download/directory/for/old/repo/packages> <path/to/download/directory/for/new/repo/packages>"
    echo "To test specific packages of repo, usage: `basename $0` -p <package file pattern> <path/to/download/directory/for/old/repo/packages> <path/to/download/directory/for/new/repo/packages>"
    echo ""
    exit 1
}

#~ =================== :: LET'S DOWNLOAD PACKAGES :: ================
SIZE_LIMIT=$2
OLD_RPM_DIR=$3
NEW_RPM_DIR=$4

echo "[#].......Checking test environment."
abi-compliance-checker
if [ $? -ne 0 ]; then
	echo "[#].......Checking requirements.";
	installPkg exuberant-ctags
	installPkg elvis-tools
	installPkg ctags
	echo "[#].......ctags available.";
	echo "[!].......NOT FOUND ABI package.";
	git clone https://github.com/lvc/abi-compliance-checker
	if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
	cd abi-compliance-checker
	installPkg perl
	sudo perl Makefile.pl -install --prefix=/usr
	if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
	cd ..
	abi-compliance-checker
	git clone https://github.com/lvc/abi-dumper
	if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
	cd abi-dumper
	sudo perl Makefile.pl -install --prefix=/usr
	if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
	cd ..
	abi-dumper
	echo "[#].......ABI dumper packages NOW AVAILABLE.";
fi
echo "[#].......ABI packages AVAILABLE.";

function all()
{
	echo "[#].......PREPARING WORKSPACE STRUCTURE."
	mkdir -p logs
	mkdir -p $OLD_RPM_DIR
	mkdir -p $NEW_RPM_DIR
	touch old-pkg-mod.list
	touch new-pkg-mod.list
	touch logs/downloaded_pkgs.log
	touch pkg2git-map.list
	
	echo "[#].......STARTING DOWNLOAD PACKAGES."
	if [ $1 == 0 ]; then
	
		wget --progress=bar:force $OLD_PKG_LIST -O old-pkg.list
		if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
		wget --progress=bar:force $NEW_PKG_LIST -O new-pkg.list
		if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
		
		for line in `cat modules_git_repo.txt`
		do
			name=${line%%[[:space:]]}
			grep "$name#" old-pkg.list>>old-pkg-mod.list
		done
		
		NR=$(awk 'END{print NR}' old-pkg-mod.list)
		echo "[#].......OLD PACKAGE LIST LOADED. [ $NR PACKAGES]"
		echo "[#].......ALL PACKAGES SELECTED."
		
		COUNT=0
		
		echo "[#].......PLEASE WAIT! DOWNLOAD WILL TAKE SOME TIME."
		for old_pkg in `awk '{print $1 "*-" $2}' old-pkg-mod.list | sed 's/.armv7l//'`
		do
			wget -q -l1 -nd -r -P $OLD_RPM_DIR -A $old_pkg.armv7l.rpm -R *-docs-*.rpm,*-test-*.rpm $OLD_REPO
			if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
			DOWNLOADED=$(find $OLD_RPM_DIR/* -type f -name $old_pkg.armv7l.rpm)
			if [[ $DOWNLOADED ]]; then
				echo "[#]....... $old_pkg.armv7l.rpm DOWNLOADED [SUCCESS]."
				LOG_RPM=${old_pkg%%-[0-9]*}
				echo "${LOG_RPM%%\*}" >> logs/downloaded_pkgs.log
			else
				echo "[!]....... $old_pkg.armv7l.rpm DOWNLOAD __________ [FAILED]."
			fi
			let COUNT=COUNT+1
			echo "[!].......[STATUS][$COUNT/$NR] PACKAGE(S) DOWNLOADED."
		done
	elif [ $1 == -1 ]; then
		SELECTED_PACKAGE=$2
		echo "[#].......$SELECTED_PACKAGE PACKAGE IS SELECTED."
		wget --progress=bar:force -l1 -nd -r -P $OLD_RPM_DIR -A *$SELECTED_PACKAGE*.rpm -R *-docs-*.rpm,*-test-*.rpm $OLD_REPO
		if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
	else
		echo "[#].......[LIMIT OF $1] PACKAGES SELECTED."
		wget -Q$1 --progress=bar:force -l1 -nd -r -P $OLD_RPM_DIR -A capi*.rpm -R *-docs-*.rpm,*-test-*.rpm $OLD_REPO
		if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
	fi
	echo "[#].......DOWNLOADING NEW PACKAGE(S)."
	COUNT=0
	for line in `cat modules_git_repo.txt`
	do
		name=${line%%[[:space:]]}
		grep "$name" new-pkg.list>>new-pkg-mod.list
	done
	for mod in `awk '{print $1 "*-" $2}' new-pkg-mod.list | sed 's/.armv7l//'`
	do
		wget -q -l1 -nd -r -P $NEW_RPM_DIR -A $mod.armv7l.rpm -R *-docs-*.rpm,*-test-*.rpm $NEW_REPO
		if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
		let COUNT=COUNT+1
		echo "[$COUNT] ___________$mod.armv7l.rpm ..........."
	done
	echo "[#].......DOWNLOADED $COUNT NEW PACKAGE(S)."
	
	echo "	
		<!DOCTYPE html>
		<html>
		<head>
		<style>
		table, th, td {
			border: 1px solid black;
		}
		</style>
		<title>ABI Compatibility Report | ${OLD_VER} to ${NEW_VER}</title>
		</head>
		<body>
		<h1>ABI Compatibility Reports Of $OLD_VER to $NEW_VER Packages</h1>
		<p>
		<table style=\"width:60%\">
		<tr>
			<td colspan=\"6\">
				<p>Base binary		: ${BASE_BINARY}</p>
				<p>Compared binary	: ${COMPARED_BINARY}</p>
				<p><a href=\"#summary\">See the Summary Report Statistics at the end of this page</a></p>
			</td>
		</tr>
		<tr>
			<th><b>Packages</b></th>
			<th>ABI Affected (%)</th>
			<th>Source Affected (%)</th>
			<th>Binary</th>
			<th>Source</th>
			<th><b>Result</b></th>
		</tr>" > compat_reports/index.html
	
	INCOMPATIBLE_COUNT=0

	for dl in `cat logs/downloaded_pkgs.log`
	do
		echo "[#].......Extracting old packages to ..."
		for old in `ls -1 $OLD_RPM_DIR | grep $dl`
		do
			if [ $old != 'usr' ] && [ $old != 'etc' ]; then
				(cd $OLD_RPM_DIR; rpm2cpio $old | cpio -idmv; cd ..)			
				if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
			fi
		done
		echo "[#].......Extracting new packages to ..."
		for new in `ls -1 $NEW_RPM_DIR | grep $dl`
		do
			if [ $new != 'usr' ] && [ $new != 'etc' ]; then
				(cd $NEW_RPM_DIR; rpm2cpio $new | cpio -idmv; cd ..)
				if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; exit 1; fi
			fi
		done
		echo "[#].......Started ABI compliance checking for \"${dl%%\*}\" package."
		DIR=$(echo $OLD_RPM_DIR | sed 's/.\///')
		NEW_DIR=$(echo $NEW_RPM_DIR | sed 's/.\///')
		
		mkdir -p $DIR/usr/lib
		mkdir -p $DIR/usr/include
		mkdir -p $DIR/usr/etc
		mkdir -p $NEW_RPM_DIR/usr/lib
		mkdir -p $NEW_RPM_DIR/usr/include
		mkdir -p $NEW_RPM_DIR/usr/etc
		
		echo "====================" >> logs/${dl%%\*}.log
		date >> logs/${dl%%\*}.log
		echo "====================" >> logs/${dl%%\*}.log
		
		COMPONENT_NAME=$(echo ${dl%%\*} | sed 's/lib//')
		echo "[#]........Component name: $COMPONENT_NAME."
		
		(cd $ABI_DIR/; abi-compliance-checker -s \
											-l lib$COMPONENT_NAME \
											-old OLD.xml -new NEW.xml \
											-headers-list $HEADER_CHECKLIST \
											-list-affected \
											-sysroot $SYS_ROOT \
											-l-full ${dl%%\*} \
											-show-retval \
											-log-path logs/${dl%%\*}.log)
												
		SYMBOLS_ABI_AFFECTED=$(awk 'END{print NR}' compat_reports/lib$COMPONENT_NAME/${OLD_VER}_to_${NEW_VER}/abi_affected.txt)
		SYMBOLS_SRC_AFFECTED=$(awk 'END{print NR}' compat_reports/lib$COMPONENT_NAME/${OLD_VER}_to_${NEW_VER}/src_affected.txt)
		
		ABI_AFFECTED=0
		SRC_AFFECTED=0
		ABI_IS_COMPAT=1
		SRC_IS_COMPAT=1
		
		COMPONENT_NAME=$(echo ${dl%%\*} | sed 's/lib//')
		(chmod 777 verdict.sh; ./verdict.sh $COMPONENT_NAME)
		
		ABI_IS_COMPAT=$(cat verdict.log | awk '{print $1}')
		SRC_IS_COMPAT=$(cat verdict.log | awk '{print $2}')
		if [ "$ABI_IS_COMPAT" -eq 0 ]; then		
			ABI_AFFECTED=$(cat affect.log | awk '{print $1}')
		fi
		if [ "$SRC_IS_COMPAT" -eq 0 ]; then
			SRC_AFFECTED=$(cat affect.log | awk '{print $2}')
		fi
		
		RESULT="<b>Compatible</b>"
		BINARY="Compatible"
		SOURCE="Compatible"
		COLOR="green"
		ABI_AFFECTED_COLOR="black"
		SRC_AFFECTED_COLOR="black"
		SRC_COLOR="green"
		LINK="lib$COMPONENT_NAME/${OLD_VER}_to_${NEW_VER}/compat_report.html"
		
		if [ -z "${SYMBOLS_ABI_AFFECTED}" -o -z "${SYMBOLS_SRC_AFFECTED}" ]; then
			RESULT="<b>Not reported</b>"
			COLOR="black"
			BINARY="--"
			SOURCE="--"
			LINK="#"
			ABI_AFFECTED="--"
			SRC_AFFECTED="--"
		elif [ "$ABI_IS_COMPAT" -eq 0 ]; then
			COLOR="red"
			RESULT="<b>Incompatible</b>"
			BINARY="Incompatible"
			ABI_AFFECTED_COLOR="red"
			
			let INCOMPATIBLE_COUNT++
					
			if [ "$SRC_IS_COMPAT" -eq 0 ]; then
				SRC_AFFECTED_COLOR="red"
				SRC_COLOR="red"
				SOURCE="Incompatible"
			elif [ "$SRC_IS_COMPAT" -eq 1 ]; then
				SRC_AFFECTED_COLOR="black"
				SOURCE="Compatible"
				SRC_COLOR="green"
			fi			
		elif [ "$ABI_IS_COMPAT" -eq 1 ]; then
			COLOR="green"
			RESULT="<b>Compatible</b>"
			
			ABI_AFFECTED_COLOR="black"
			SRC_AFFECTED_COLOR="black"
			SRC_COLOR="green"
			SOURCE="Compatible"
		fi
		
		PKG2GIT_MAP=$(grep "${dl%%[[:space:]]}.armv7l" old-pkg-mod.list | awk '{print $3}')
		for item in `echo $PKG2GIT_MAP`
		do
			echo "${dl%%\*},${item}" >> pkg2git-map.list
			break;
		done

		echo "
			<tr>
			<td><a href=\"${LINK}\">$COMPONENT_NAME</a></td>
			<td style=\"color:${ABI_AFFECTED_COLOR}\">${ABI_AFFECTED}</td>
			<td style=\"color:${SRC_AFFECTED_COLOR}\">${SRC_AFFECTED}</td>
			<td style=\"color:${COLOR}\">${BINARY}</td>
			<td style=\"color:${SRC_COLOR}\">${SOURCE}</td>
			<td style=\"color:${COLOR}\">${RESULT}</td>
			</tr>" >> compat_reports/index.html							
	
		#~ options:
		#~ -report-path compat_reports/${dl%%\*}/${libc%%.so.[0-9]*}/${DIR}_to_${NEW_DIR}/${dl%%\*}_compat_report.html
		#~ -cross-gcc $GCC_PATH
		#~ -b firefox -open \
		#~ -logging-mode a \
		#~ -cross-prefix arm-linux-gnueabi
				
		remove -pkg-comp
		echo "[#].......Removed package components for package: ${dl%%\*}"
		REPORTED=$(find $ABI_DIR -type d -name compat_reports)
		if [[ $REPORTED ]]; then
			echo "[#].......ABI COMPLIANCE REPORT IS READY TO: \"$ABI_DIR/compat_reports\""
		else
			echo "[#].......ABI COMPLIANCE REPORTS IS FAILED TO GENERATE. CHECK abi.conf and library descriptor (OLD.xml, NEW.xml)."		
		fi
	done
	
	PKGS_REPORTED=$(find ./compat_reports/. -type d -name lib* | awk 'END{print NR}')
	
	COMPATIBILITY_RATE=0
	COMPATIBILITY_RATE=$(bc -l <<< "scale = 2; $INCOMPATIBLE_COUNT / $PKGS_REPORTED")
		
	echo "
		<tr>
			<td id=\"summary\" colspan=\"6\">
				<p>Total packages : ${PKGS_REPORTED}</p>
				<p>Incompatible packages : ${INCOMPATIBLE_COUNT}</p>
				<p>Incompatible rate : ${COMPATIBILITY_RATE}</p>
			</td>
		</tr>
		</table>
		</p>
		</body>
		</html>" >> compat_reports/index.html
		
	echo "[#].......INDEX PAGE IS PREPARED TO: \"compat_reports/index.html\"."
		
	echo "[!].......Please check for any missing platform headers exists to: logs/missing_headers.log."
	echo "====================" >> logs/missing_headers.log
	date >> logs/missing_headers.log
	echo "====================" >> logs/missing_headers.log
	(grep -Hnr 'fatal error' ./logs --exclude=missing_headers.log >> logs/missing_headers.log)
		
	echo "[#].......STARTED TO GENERATE SUMMARY REPORT."
	(chmod 777 rpt-gen.sh; ./rpt-gen.sh)
	if [ $? -ne 0 ]; then echo "[!].......Aborting [Command failure]."; remove -temp; exit 1; fi
	echo "[#].......Summary report of ABI compatibility reports is generated to: \"compat_reports/report_summary.xls\"."
	
	remove -temp
}

if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]; then
    echo ""
    helpusage
elif [ -z "$OLD_REPO" ] || [ -z "$NEW_REPO" ]; then
	echo "[!].......[abi.conf][Edit the abi.conf file for working repo address.]"
elif [ "-all" == "$1" ]; then
	OLD_RPM_DIR=$2
	NEW_RPM_DIR=$3
	all 0 
elif [ "-p" == "$1" ]; then
	if [ -z "$2" ] || [ -z "$3" ] || [ -z "$3" ]; then
		echo ""
		helpusage
	fi
	all -1 $2
elif [ "-limit" == "$1" ]; then
	if [ -z "$2" ] || [ -z "$3" ] || [ -z "$3" ]; then
		echo ""
		helpusage
	fi
	all $SIZE_LIMIT $OLD_RPM_DIR $NEW_RPM_DIR
else
    echo ""
    echo "Invalid subcommand: $1"
    helpusage
fi
