package planner;

import planner.*;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.*;

/**
 * Basic tests for the {@link Allocator.allocate} method in the
 * {@link Allocator} implementation class.
 * 
 * Write your own junit4 tests for the method here.
 */
public class AllocatorTest {

    @Test(timeout = 5000)
    public void test() {
    	
//    	 try {
//    		List<Event> events = new ArrayList<Event>();
//    		events.add(new Event("E1", 60));
//    		events.add(new Event("E2", 110));
//    		events.add(new Event("E3", 10));
//    		 
//			List<Venue> venues = VenueReader.read(
//			         "read_03_correctlyFormatted_manyVenues.txt");
//			Map<Event, Venue> map = Allocator.allocate(events, venues);
//			Set<Event> eventSet = map.keySet();
//			for (Event event: eventSet) {
//				s
//			}
//			
//			
//		} catch (IOException | FormatException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
        Assert.fail();
    }

}
